package com.rishab.java8streams.dao;

import java.util.List;

import com.rishab.java8streams.model.Employee;

public interface EmployeeDAO {

	// SELECT
	public List<Employee> getAllEmployee();
	/*public List<Employee> getAllEmployeeByBand(char band);
	public Employee getEmployeeById(int empNo);
	
	// INSERT
	public void addEmployee(Employee employee);
	
	// UPDATE
	public Employee updateEmployee(Employee employee);
	
	// DELETE
	public void deleteEmployee(int empNo);*/
	
}
