package com.rishab.java8streams.service;

import java.util.List;

import com.rishab.java8streams.model.Employee;

public interface EmployeeService {

	public List<Employee> getAllEmployee();
}
